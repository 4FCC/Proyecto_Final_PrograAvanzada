#include <iostream>
#include <vector>
#include <algorithm>

// Clase base que representa a una persona
class Persona {
public:
    // Obtiene el ID único de la persona
    int obtenerID() const {
        return ID;
    }

    // Obtiene el nombre de la persona
    std::string obtenerNombre() const {
        return nombre;
    }

    // Obtiene la edad de la persona
    int obtenerEdad() const {
        return edad;
    }

protected:
    // Constructor protegido para garantizar que la clase solo se pueda instanciar mediante las clases derivadas
    Persona() {
        ID = generarIDUnico();
    }

private:
    // Genera un ID único utilizando un contador estático
    static int generarIDUnico() {
        static int contadorID = 0;
        return ++contadorID;
    }

    int ID;             // ID único de la persona
    std::string nombre; // Nombre de la persona
    int edad;           // Edad de la persona
};

// Clase derivada que representa a un empleado
class Empleado : public Persona {
public:
    // Obtiene el salario del empleado
    double obtenerSalario() const {
        return salario;
    }

    // Obtiene el departamento al que pertenece el empleado
    std::string obtenerDepartamento() const {
        return departamento;
    }

protected:
    // Constructor protegido para garantizar que la clase solo se pueda instanciar mediante las clases derivadas
    Empleado() {}

private:
    double salario;      // Salario del empleado
    std::string departamento; // Departamento al que pertenece el empleado
};

// Clase derivada que representa a un gerente, hereda de Empleado
class Gerente : public Empleado {
public:
    // Obtiene el nivel jerárquico del gerente
    std::string obtenerNivelJerarquico() const {
        return nivelJerarquico;
    }

private:
    std::string nivelJerarquico; // Nivel jerárquico del gerente
};

// Clase derivada que representa a un contratista, hereda de Empleado
class Contratista : public Empleado {
public:
    // Obtiene la duración del contrato del contratista
    int obtenerDuracionContrato() const {
        return duracionContrato;
    }

private:
    int duracionContrato; // Duración del contrato del contratista
};

// Clase derivada que representa a un practicante, hereda de Empleado
class Practicante : public Empleado {
public:
    // Obtiene la universidad a la que pertenece el practicante
    std::string obtenerUniversidad() const {
        return universidad;
    }

private:
    std::string universidad; // Universidad a la que pertenece el practicante
};

int main() {
    std::vector<Persona*> listaPersonas;

    // Crear objetos de diferentes tipos de empleados
    Gerente gerente;
    Contratista contratista;
    Practicante practicante;

    // Agregar a la lista de personas
    listaPersonas.push_back(&gerente);
    listaPersonas.push_back(&contratista);
    listaPersonas.push_back(&practicante);

    // Ordenar la lista por nombre (ejemplo de ordenación, puede ser cualquier criterio)
    std::sort(listaPersonas.begin(), listaPersonas.end(),
        [](const Persona* a, const Persona* b) {
            return a->obtenerNombre() < b->obtenerNombre();
        });

    // Realizar otras operaciones según sea necesario

    return 0;
}
